library(testthat)
library(infercnv)

test_check("infercnv")
